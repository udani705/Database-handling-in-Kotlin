package com.example.a6

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase


class DBhelper  (context: Context) : SQLiteOpenHelper(context,"University",
    null, 1) {

    companion object {
        const val TABLE_NAME = "Student"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE $TABLE_NAME(index_no TEXT, "+" name TEXT, nic TEXT, age INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    //after all these, create db connection in Mainactivity

    fun insertData(indexNo: String?, name: String?, nic:String?, age: Int) {
        val values = ContentValues()
        values.put("index_no", indexNo)
        values.put("name", name)
        values.put("age", age)
        values.put("nic", nic)
        val db = this.writableDatabase
        db.insert(TABLE_NAME, null,values)
    }

    //dbhelper class is over
    //now create interface 2 & go back to mainactivity




}