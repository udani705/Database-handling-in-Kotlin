package com.example.a6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.annotation.SuppressLint
import android.widget.TextView

class SecondScreen : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_screen)

    // now you created screen 2
    // after creating intface 2, put setonclicklistener to btn on mainactivity


        //after adding setonclicklistener
        //call dbhelper in here & assign variables & pass values from db to Screen 2

        var helper = DBhelper(applicationContext)

        val name = findViewById<TextView>(R.id.ansname)
        val age = findViewById<TextView>(R.id.ansage)
        val nic = findViewById<TextView>(R.id.ansnic)

        val i = intent
        val nicValue = i.getStringExtra("nicpara")
        val db = helper.readableDatabase
        val res = db.rawQuery("SELECT * FROM Student WHERE nic='$nicValue'",
            null)

        while (res.moveToNext()) {
            val nicis = res.getString(res.getColumnIndex("nic"))
            val ageis = res.getString(res.getColumnIndex("age"))
            val nameis = res.getString(res.getColumnIndex("name"))
            name.text = nameis
            age.text = ageis
            nic.text = nicis
        }


        //now youre done
    }
}