package com.example.a6

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private var indexglobal = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // after creating interface 1, now go and create DBHelper kotlin class

        var helper = DBhelper(applicationContext)

        //after creating db con run main application
        // go back to dbhelper class & insert data using fun


        //you created intface 2..
        // now  add setonclicklistener to btn,
        // before that assign variables like below & equal indexglobal to 0

        val btn: Button = findViewById(R.id.btn)
        val name: EditText = findViewById(R.id.entname)
        val nic: EditText = findViewById(R.id.entnic)
        val age: EditText = findViewById(R.id.entage)

        btn.setOnClickListener {
            var index = ++indexglobal
            helper.insertData(
                index.toString(),
                name.text?.toString()!!,
                nic.text?.toString()!!,
                age.text?.toString()?.toInt()!!
            )

            val nicval = nic.text.toString()

            val bundle = Bundle()
            bundle.putString("nicpara", nicval)

            val gotoNextScreen = Intent(applicationContext, SecondScreen::class.java)
            gotoNextScreen.putExtras(bundle)
            startActivity(gotoNextScreen)


        }


        //now this is over, and go to Screen 2
    }

}